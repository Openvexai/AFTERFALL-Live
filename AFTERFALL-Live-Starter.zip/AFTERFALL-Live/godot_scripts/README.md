# Godot 4 setup

1. Copy `LiveContent.gd` into your Godot project's scripts folder.
2. Add a Node to your scene and attach this script.
3. Set `manifest_url` to the raw URL of `skins/manifest.json`.
4. Call `fetch_manifest()` when the player reaches the online content screen.
5. Read the `skins` array and show available items in your UI.
6. After the player chooses a downloadable item, call `download_pck(url, file_name, sha256)`.

Important:
- This is a starter example, not a complete production download manager.
- Test PCK compatibility and resource paths with your exact Godot export.
- For large files, prefer streaming/chunked downloads and a CDN/object storage service.
- Do not trust the client to grant itself a skin or spin result.
- `load_resource_pack()` loads resources; your game still needs code to discover and display those resources.
