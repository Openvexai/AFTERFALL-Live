extends Node
class_name LiveContent

## Godot 4 starter: downloads a public JSON manifest and an optional PCK.
## Set manifest_url in the Inspector to the raw GitHub URL of skins/manifest.json.

signal manifest_loaded(data: Dictionary)
signal download_finished(path: String)
signal operation_failed(message: String)

@export var manifest_url: String
@export var download_directory := "user://live_content"

var http: HTTPRequest
var download_http: HTTPRequest
var _pending_path := ""

func _ready() -> void:
    http = HTTPRequest.new()
    download_http = HTTPRequest.new()
    add_child(http)
    add_child(download_http)
    http.request_completed.connect(_on_manifest_completed)
    download_http.request_completed.connect(_on_download_completed)
    DirAccess.make_dir_recursive_absolute(
        ProjectSettings.globalize_path(download_directory)
    )

func fetch_manifest() -> void:
    if manifest_url.is_empty():
        operation_failed.emit("Set manifest_url first.")
        return
    var err := http.request(manifest_url)
    if err != OK:
        operation_failed.emit("Manifest request failed: %s" % err)

func _on_manifest_completed(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
    if result != HTTPRequest.RESULT_SUCCESS or code != 200:
        operation_failed.emit("Manifest HTTP error: %s" % code)
        return
    var parsed = JSON.parse_string(body.get_string_from_utf8())
    if typeof(parsed) != TYPE_DICTIONARY:
        operation_failed.emit("Manifest JSON is invalid.")
        return
    manifest_loaded.emit(parsed)

func download_pck(url: String, file_name: String, expected_sha256: String) -> void:
    if url.is_empty() or file_name.is_empty():
        operation_failed.emit("Download URL or file name is empty.")
        return
    if file_name.get_file() != file_name or not file_name.ends_with(".pck"):
        operation_failed.emit("Use a simple .pck file name.")
        return
    _pending_path = download_directory.path_join(file_name)
    var err := download_http.request(url)
    if err != OK:
        operation_failed.emit("Download request failed: %s" % err)
        return
    # Store expected hash for verification after the response.
    set_meta("expected_sha256", expected_sha256)

func _on_download_completed(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
    if result != HTTPRequest.RESULT_SUCCESS or code != 200:
        operation_failed.emit("Download HTTP error: %s" % code)
        return
    var file := FileAccess.open(_pending_path, FileAccess.WRITE)
    if file == null:
        operation_failed.emit("Cannot write downloaded file.")
        return
    file.store_buffer(body)
    file.close()

    var expected := str(get_meta("expected_sha256", ""))
    if expected.length() != 64 or expected.begins_with("REPLACE_"):
        DirAccess.remove_absolute(ProjectSettings.globalize_path(_pending_path))
        operation_failed.emit("A real SHA-256 hash is required.")
        return

    var actual := FileAccess.get_sha256(_pending_path)
    if actual.to_lower() != expected.to_lower():
        DirAccess.remove_absolute(ProjectSettings.globalize_path(_pending_path))
        operation_failed.emit("SHA-256 verification failed.")
        return

    if not ProjectSettings.load_resource_pack(_pending_path, false):
        operation_failed.emit("Godot could not load the PCK.")
        return

    download_finished.emit(_pending_path)
